package jif.runtime;

/* 
 * class added by Boniface 3/17/06
 */

import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.InvalidKeyException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.security.PublicKey;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.CertificateException;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

import java.util.Collection;
import java.util.Iterator;

import jif.lang.*;

public class AuthKey
{
	final public KeyStore keystore;
	final public char[] password;
	final public String caAlias;
	final public Certificate trustedCA;
	final public String certsDir;  // where Certs are stored--in real world, should use LDAP
	
	// can only be called by AuthKey.makeAuthKey(...) which can only be called by Runtime
	private AuthKey(String keystoreFile, char[] password, String trustedCAfilename)
	{
		this.certsDir = "certs/";  // relative path
		
		this.password = new char[password.length];
		System.arraycopy(password,0,this.password,0,password.length);
		
		KeyStore _keystore = null;
		Certificate _trustedCA = null;
		String _caAlias = null;
		try {
			CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
			_trustedCA = certFactory.generateCertificate(new FileInputStream(trustedCAfilename));
			_keystore = KeyStore.getInstance(KeyStore.getDefaultType());
			_keystore.load(new FileInputStream(keystoreFile), this.password);
			_caAlias = _keystore.getCertificateAlias(_trustedCA); // ensures that the user trusts the CA, bcs it's in the keystore
		} catch (KeyStoreException kse) {kse.printStackTrace();
		} catch (CertificateException ce) {ce.printStackTrace();
		} catch (NoSuchAlgorithmException nsae) {nsae.printStackTrace();
		} catch (FileNotFoundException fnfe) {fnfe.printStackTrace();
		} catch (IOException ioe) {ioe.printStackTrace();}    
		this.keystore = _keystore;
		this.caAlias = _caAlias;
		this.trustedCA = _trustedCA;
	}
	
	// shouldn't be exposed to Jif -- can only be called by Runtime
	public static AuthKey makeAuthKey(String keystoreFile, char[] password, String trustedCAfilename)
	{
		return new AuthKey(keystoreFile,password,trustedCAfilename);
	}
	
	/**
	 * checks whether the certificate corresponding to the alias p.name() (if it exists) is certified by our trusted CA
	 */
	public boolean isValidPrincipal(Principal p)
	{
		return isValidPrincipal(p.name());
	}

	/**
	 * checks whether the certificate corresponding to the alias p.name() (if it exists) is certified by our trusted CA
	 */
	public boolean isValidPrincipal(String name)
	{
		try {
//			System.out.println("Entering isValidPrincipal(" + name + ") : ");
			FileInputStream fis = new FileInputStream(certsDir + name + "Cert.der");
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			Certificate cert = cf.generateCertificate(fis);
			//System.out.println(name + "'s certificate: \n" + cert);
			cert.verify(this.trustedCA.getPublicKey());  // throws a SignatureException if not verified
		} catch (NoSuchAlgorithmException nsae) {nsae.printStackTrace(); return false;
		} catch (InvalidKeyException ike) {ike.printStackTrace(); return false;
		} catch (NoSuchProviderException nspe) {nspe.printStackTrace(); return false;
		} catch (FileNotFoundException fnfe) {fnfe.printStackTrace(); return false;
		} catch (CertificateException ce) {ce.printStackTrace(); return false;
		} catch (NullPointerException e) {e.printStackTrace(); return false;
		} catch (SignatureException se) {return false;  // not verified
		}
		return true;  // no exception thrown, so must have been verified??
	}

	/** 
	 * validates the principal and makes sure the principal's private key is in the store
	 */
	public boolean userHasPrivateKey(Principal p)
	{
		if (p == null || !isValidPrincipal(p)) return false;      // ensures public key, certified by trusted CA in keystore
		else {
			try {
				if (keystore.isKeyEntry(p.name())) { // true iff corresponding private key installed in keystore
					// verify certificate chain
					Certificate[] certChain = keystore.getCertificateChain(p.name());
					return (certChain != null && certChain[certChain.length-1].equals(this.trustedCA));
					//return true;
				}
			} catch (KeyStoreException kse) {kse.printStackTrace(); return false;
			} catch (ArrayIndexOutOfBoundsException e) {return false; // no chain!
			}
		}
		return false;
	}

	public PublicKey getPublicKey(String name)
	{
		if (!isValidPrincipal(name)) return null;
		else {
			try {
				FileInputStream fis = new FileInputStream(certsDir + name + "Cert.der");
				CertificateFactory cf = CertificateFactory.getInstance("X.509");
				Certificate cert = cf.generateCertificate(fis);
				return cert.getPublicKey();
			} catch (FileNotFoundException fnfe) {fnfe.printStackTrace(); return null;
			} catch (CertificateException ce) {ce.printStackTrace(); return null;
			} catch (NullPointerException e) {e.printStackTrace(); return null;
			}
		}
	}
	
	public PrivateKey getPrivateKey(Principal p)
	{
		if (!userHasPrivateKey(p)) return null;
		else {
			try {
				return ((PrivateKey)keystore.getKey(p.name(),this.password));  // presumes that store pass = key pass
			} catch (KeyStoreException kse) {kse.printStackTrace(); return null;			
			} catch (UnrecoverableKeyException uke) {uke.printStackTrace(); return null;
			} catch (NoSuchAlgorithmException nsae) {nsae.printStackTrace(); return null;
			}			
		}
	}	
}