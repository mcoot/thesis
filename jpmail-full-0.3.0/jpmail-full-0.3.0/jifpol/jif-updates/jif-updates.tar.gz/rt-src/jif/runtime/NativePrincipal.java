package jif.runtime;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Map;
import java.util.HashMap;

import jif.lang.*;

/**
 * A NativePrincipal represents the file system users and groups.
 */
public class NativePrincipal implements Principal {
	private final String name;
    private final Set superiors = new LinkedHashSet();
    
    private NativePrincipal(String name) {
        this.name = name;
    }

    /**
     * Added by Boniface 3/24/06
     */
    static private final Map allNatives;  // contains all existing NativePrincipals
    
    static {
    		allNatives = new HashMap();
    }
    
    /**
     * Added by Boniface 3/24/06
     */
    static NativePrincipal getInstance(String name)
    {	
    		if (allNatives.containsKey(name)) {
//    			System.out.println(name.toString() + " already in NativePrincipal store.");
    			return (NativePrincipal)allNatives.get(name);
    		}
    		else {
    			System.out.println("Adding " + name + " to NativePrincipal store");
    			NativePrincipal p = new NativePrincipal(name);
    			allNatives.put(name,p);
    			return p;
    		}
    }

    /**
     * Added by Boniface 3/17/06
     * This method adds a single superior to the NativePrincipal
     * For the purpose of connecting this NativePrincipal with a non-native principal
     * The authorization and necessary checking for this should be done in Runtime
     */
    public void addDelegateTo(Principal superior) {
//    		System.out.println("Adding " + name + " -> " + superior.name());
    		if (!superior.equals(this)) {  // avoid cyclic dependency
    			superiors.add(superior);
    		}
    }
    
    public String name() {
        return name;
    }

    public Set superiors() {
        return this.superiors;
    }

/*    public String toString() {
    		String retval = name + " -> ";
    		for (Iterator iter = superiors.iterator(); iter.hasNext(); )
            retval += ((Principal)iter.next()).toString();
           
    		return retval; 
    }
*/
    public boolean delegatesTo(Principal p) {
        return superiors.contains(p);
    }

    public boolean isAuthorized(Object authorizationProof, Closure closure, Label lb) {
        // The default is that this principal authorizes no closures.
        return false;
    }
    
    public Principal[] findChainDownto(Principal q) {
        // don't even try! We don't have any information
        // about who we can act for.
        return null;
    }

    public Principal[] findChainUpto(Principal p) {
//    		System.out.println("(" + toString() + ").findChainUpTo(" + p.toString() + ")");
    		
    		// go through our set of superiors, and see if we can find a chain
        // from them to p.
        Principal[] chain;
        for (Iterator iter = superiors.iterator(); iter.hasNext(); ) {
            Principal s = (Principal)iter.next();

            Principal[] exclude = addToChainBottom(null,this);
            chain = PrincipalUtil.findDelegatesChain(p, s, exclude);
            if (chain != null) {
                // success!
                // create a longer chain with this at the bottom 
                return addToChainBottom(chain, this);
            }
        }
        return null;
    }

    public Principal[] findChainUpto(Principal p, Principal[] exclude) {
//    		System.out.println("(" + toString() + ").findChainUpToX(" + p.toString() + ")");
//    		System.out.print("Exclude = ");
//    		for (int i = 0; i < exclude.length; i++)
//    			System.out.print(exclude[i].toString() + " , ");
//    		System.out.println("");
//    		System.out.print("Superiors = ");
//        for (Iterator iter = superiors.iterator(); iter.hasNext(); ) {
//            Principal s = (Principal)iter.next();
//            System.out.print(s.toString());
//        }
//        System.out.println("");
    		
    		// go through our set of superiors, and see if we can find a chain
        // from them to p.
        Principal[] chain;
        for (Iterator iter = superiors.iterator(); iter.hasNext(); ) {
            Principal s = (Principal)iter.next();

            boolean cycle = false;
            for (int j = 0; !cycle && exclude != null && j < exclude.length; j++)
        			if (s == exclude[j]) cycle = true; // also test equals()-equality? 
            if (!cycle) {
            		addToChainBottom(exclude,this);
            		chain = PrincipalUtil.findDelegatesChain(p, s, exclude);
	            if (chain != null) {
	                // success!
	                // create a longer chain with this at the bottom 
	                return addToChainBottom(chain, this);
	            }
            }
        }
        return null;
    }
        
    public boolean equals(Object o) {
        if (o == null) return false;
        if (o instanceof Principal) {
            return equals((Principal)o);
        }
        return false;
    }
    
    public boolean equals(Principal p) {
        return (this.name == p.name() || (this.name != null && 
                this.name.equals(p.name()))) &&
                	this.getClass() == p.getClass();        
    }
    
    public int hashCode() {
        return name.hashCode();
    }

    /**
     * Create a new chain of length <code>chain.length+1</code>, such that
     * the last element of the new chain is <code>principal</code>, and 
     * all other elements are copied over from <code>chain</code>.
     */
    static protected Principal[] addToChainBottom(Principal[] chain, Principal principal) {
        if (chain == null) {
            Principal[] newChain = new Principal[1];
            newChain[0] = principal;
            return newChain;
        }
        
        Principal[] newChain = new Principal[chain.length + 1];
        for (int i = 0; i < chain.length; i++) {
            newChain[i] = chain[i];
        }
        newChain[chain.length] = principal;
        return newChain;
    }

    /**
     * Create a new chain of length <code>chain.length+1</code>, such that
     * the first element of the new chain is <code>principal</code>, and 
     * all other elements are copied over from <code>chain</code>, offset by one.
     */
    static protected Principal[] addToChainTop(Principal principal, Principal[] chain) {
        if (chain == null) {
            Principal[] newChain = new Principal[1];
            newChain[0] = principal;
            return newChain;
        }
        
        Principal[] newChain = new Principal[chain.length + 1];
        newChain[0] = principal;
        for (int i = 0; i < chain.length; i++) {
            newChain[i+1] = chain[i];
        }
        return newChain;
    }
}
