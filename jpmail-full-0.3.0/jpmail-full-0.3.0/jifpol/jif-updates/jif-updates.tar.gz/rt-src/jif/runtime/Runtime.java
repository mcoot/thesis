package jif.runtime;

import java.io.*;
import java.util.*;
import java.util.GregorianCalendar;
import java.util.LinkedList;

import java.security.PublicKey;
import java.security.PrivateKey;

import jif.lang.*;

/**
 * The runtime interface between Jif programs and the underlying system.
 */
public class Runtime {
    /**
     * The principal under whose authority the JVM is running.
     */
    private Principal dynp;
    private AuthKey auth;		// added by Boniface 3/17/06

    private Runtime(Principal p) {
        this.dynp = p;
        this.auth = null;
    }

    private Runtime(Principal p, AuthKey auth) {
        this.dynp = p;
        this.auth = auth;
    }

    /**
     * Gets a <code>Runtime</code> object parameterized with the
     * principal <code>p</code>.
     */
    public static Runtime getRuntime(Principal p) throws SecurityException {
        //check if the current user can act for p
        Principal user = user(p);
        if (!PrincipalUtil.actsFor(user, p)) {
            throw new SecurityException("The current user does not act for "
                    + p.name() + ".");
        }
        return new Runtime(p);
    }

    /**
     * Added by Boniface 3/17/06
     * Gets a <code>Runtime</code> object parameterized with the
     * principal <code>p</code>.  p need not act for the user, but
     * the user trusts p   
     * Explanation: 
     * Delegating from a user to a principal:
	 * I think it is reasonable to delegate to a principal X given the following:
	 * 1) we trust a CA
	 * 2) we have a certificate (in a keystore) with alias X validated by the CA
	 * 3) we have the private key (in the keystore) corresponding to the certificate
	
	 * Thus, there should be an extension to the runtime system which will delegate from NativePrincipal(user) to X,
	 * given the following things:
	 * 1) X (the name of the principal we want to delegate to
	 * 2) a keystore
	 * 3) a trusted CA (should be a certificate or could be an alias in the keystore?)
     */
    public static Runtime getRuntime(Principal p, String keyStoreFilename, char[] password, String trustedCAfilename) throws SecurityException {
        	//check if the current user can act for p using KeyStore and trusted CA in AuthKey
    		String pwd = null;
    		try {
    			pwd = new String(password);
    		} catch (NullPointerException e) {
    			throw new SecurityException("The current user does not have the trusted-CA-verified private key for "
                    + p.name() + ".");
    		}
    		AuthKey auth = AuthKey.makeAuthKey(keyStoreFilename,password,trustedCAfilename);
    		Principal user = user(p,auth);
    		if (!PrincipalUtil.actsFor(user, p) || !PrincipalUtil.actsFor(p,user)) {
            throw new SecurityException("The current user does not have the trusted-CA-verified private key for "
                    + p.name() + ".");
    		}

    		return new Runtime(p,auth);
    }

    /** Get the current user  */
    public static Principal user(Principal parameter) {
        String username = currentUser();
        return NativePrincipal.getInstance(username);
    }

    /** 
     *  added by Boniface 03/17/06
     *  Get the current user (with possible delegation to parameter, pending auth checks out) 
     *  should not be exposed to Jif, because AuthKey should not be exposed
     *  only called by getRuntime(...)
     */
    private static Principal user(Principal parameter, AuthKey auth) {
		String username = currentUser();
		if (auth.userHasPrivateKey(parameter)) {
			NativePrincipal p = NativePrincipal.getInstance(username);
			p.addDelegateTo(parameter);
			return p;
		}
		else return NativePrincipal.getInstance(username);
    }

    /** 
     *  added by Boniface 03/17/06
     *  Make an Authorization key context for public/private keys 
     *  we bake in the parameters (keystore location and trustedCA)
     *  This could be parameterized through compiler
     */
    private AuthKey getAuthKey(char[] password)
    {
    		return AuthKey.makeAuthKey("certs/.keystore",password,"certs/cacert.pem");
    }

	/** 
	 * added by Boniface 03/17/06
	 * Make an Authorization key context for public/private keys 
	 * user may pass in appropriate files for this
	 * the only questionable one is the trustedCAfilename -- this should be set externally somehow
	 */
	private AuthKey getAuthKey(String keyStoreFilename, char[] password, String trustedCAfilename)
	{
		return AuthKey.makeAuthKey(keyStoreFilename,password,trustedCAfilename);
	}

	/**
	 * added by Boniface 03/17/06
	 * @param name a principal name
	 * @return public key from authorization context if it's valid (according to Trusted CA), else null
	 */ 
	public PublicKey getPublicKey(String name)
	{
		return auth.getPublicKey(name);
	}
	
	/**
	 * added by Boniface 03/17/06
	 * @return return the private key of the principal who parameterizes the Runtime environment
	 */
	public PrivateKey getPrivateKey()
	{
		return auth.getPrivateKey(dynp);
	}
	/**
     * Returns <code>{p:}</code> as the default label, where <code>p</code> is
     * the principal parameter of this <code>Runtime</code> object.
     */
    private Label defaultLabel() {
        return LabelUtil.privacyPolicyLabel(dynp, new LinkedList());
    }

    /**
     * Opens a file output stream to write a file with the specific <code>name</code>.
     *
     * @param name     the file name
     * @param append   if true, then bytes will be written to the end of the file
     *                 rather than the beginning
     * @param L        the label parameter of the resulting <code>FileOutputStream</code>
     *
     * @exception  FileNotFoundException
     *      if the file exists but is a directory rather than a regular file,
     *      does not exist but cannot be created, or cannot be opened for any
     *      other reason.
     *
     * @exception  SecurityException
     *      if <code>l</code> is unable to relabel to the Jif label derived from
     *      the ACL of the file.
     */
    public FileOutputStream openFileWrite(String name, boolean append, Label L)
            throws IOException, SecurityException {
//        System.out.println("...Opening file for write...");
        File f = new File(name);
        boolean existed = f.exists();

        if (existed) {
            Label acLabel = FileSystem.labelOf(name);
            if (!L.relabelsTo(acLabel)) {
                throw new SecurityException("The file " + name
                        + "doesn't have sufficient access restrictions.");
            }
        }

        FileOutputStream fos = new FileOutputStream(name, append);

        if (!existed) {
            fos.flush();
//            FileSystem.setPolicy(name, (PrivacyPolicy)L.policy());
        }
        return fos;
    }

    /** Opens a file input stream for reading from the file with the specific
     *  <code>name</code>.
     *
     *  @param name     the file name
     *  @param L        the the label parameter of the resulting <code>FileInputStream</code>
     *
     *  @exception  SecurityException
     *      if <code>l</code> is less restrictive than the Jif label derived from
     *      the ACL of the file.
     */
    public FileInputStream openFileRead(String name, Label L)
            throws FileNotFoundException, SecurityException {
//    		System.out.println("...Opening file for read...");
//    		System.out.println("L is " + L.toString());
//    		System.out.println("Runtime owner is " + getUser().toString());
        Label acLabel = FileSystem.labelOf(name);
//        System.out.println("acLabel is " + acLabel);
//        System.out.println("acLabel.owner is " + ((PrivacyPolicy)acLabel).owner().toString());
        if (acLabel.relabelsTo(L)) return new FileInputStream(name);
        
        throw new SecurityException("The file has more restrictive access "
                + "control permissions than " + L.toString());
    }

    /**
     * Gets the standard error output.
     * The output channel is parameterized by <code>l</code>.
     */
    public PrintStream stderr(Label l) {
        if (l.relabelsTo(defaultLabel())) return System.err;

        throw new SecurityException("The standard error output is not "
                + "sufficiently secure.");
    }

    /**
     * Gets the standard output.
     * This output channel is parameterized by <code>l</code>.
     */
    public PrintStream stdout(Label l) {
        if (l.relabelsTo(defaultLabel())) return System.out;
        
        throw new SecurityException("The standard output is not "
                + "sufficiently secure.");
    }

    /**
     * Gets the standard input.
     * This input channel is parameterized by <code>l</code>.
     */
    public InputStream stdin(Label l) {
        if (defaultLabel().relabelsTo(l)) return System.in;
        
        throw new SecurityException("The standard output is not "
                + "sufficiently secure.");
    }

    /**
     * Get the standard output parameterized by the default label, which
     * has only one reader: the principal of this <code>Runtime</code> object.
     */
    public PrintStream out() {
        return System.out;
    }

    /**
     * Get the standard input parameterized by the default label, which
     * has only one reader: the principal of this <code>Runtime</code> object.
     */
    public InputStream in() {
        return System.in;
    }

    /**
     * Get the standard error output parameterized by the default label, which
     * has only one reader: the principal of this <code>Runtime</code> object.
     */
    public PrintStream err() {
        return System.err;
    }

    public static native String currentUser();

    public static int currentYear(Principal dummy) {
        return new GregorianCalendar().get(Calendar.YEAR);
    }
    public static int currentMonth(Principal dummy) {
        return new GregorianCalendar().get(Calendar.MONTH) - Calendar.JANUARY + 1;
    }
    public static int currentDayOfMonth(Principal dummy) {
        return new GregorianCalendar().get(Calendar.DAY_OF_MONTH);
    }
    static {
        System.loadLibrary("jifrt");
    }
    
}